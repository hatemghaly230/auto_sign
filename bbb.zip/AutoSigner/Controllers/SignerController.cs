﻿
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Threading.Tasks;
using System.Web.Http;

namespace AutoSigner.Controllers
{
    public class SignerController : ApiController
    {
       
        public async Task<JObject> Get([FromUri]string tok)
        {
           // ApiHelper obj = new ApiHelper();
           // var token = obj.GetToken(@"https://id.eta.gov.eg", "9683e32b-5f34-425f-a63f-ae88021b31de", "9d5c18ea-f4fa-4593-a798-d62872c88796");


            TokenSigner tokenSigner = new TokenSigner();
           
            string json = tok;

            //Begin Code

            string cades = "";

            JObject request = JsonConvert.DeserializeObject<JObject>(json, new JsonSerializerSettings()
            {
                FloatFormatHandling = FloatFormatHandling.String,
                FloatParseHandling = FloatParseHandling.Decimal,
                DateFormatHandling = DateFormatHandling.IsoDateFormat,
                DateParseHandling = DateParseHandling.None
            });

            //Start serialize
            string canonicalString = tokenSigner.Serialize(request);
            // retrieve cades
            
                cades = tokenSigner.SignWithCMS(canonicalString);
            

            JObject signaturesObject = new JObject(
                                   new JProperty("signatureType", "I"),
                                   new JProperty("value", cades));
            JArray signaturesArray = new JArray();
            signaturesArray.Add(signaturesObject);
            request.Add("signatures", signaturesArray);
            string fullSignedDocument = "{\"documents\":[" + request.ToString() + "]}";
            //File.WriteAllBytes(@"E:\FullSignedDocument.json", Encoding.UTF8.GetBytes(fullSignedDocument));
            //


            //return JsonConvert.SerializeObject(fullSignedDocument);
            var j = JObject.Parse(fullSignedDocument);
             return j;
        }
    }
}
