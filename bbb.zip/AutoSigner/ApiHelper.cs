﻿using AutoSigner.Models;
using Newtonsoft.Json;
using RestSharp;
using System.Net;


namespace AutoSigner
{
    public class ApiHelper
    {
        public string token;
        public string GetToken(string idAddress, string userId, string userSecret)
        {

            ServicePointManager.SecurityProtocol = SecurityProtocolType.Ssl3 | SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;

            var client = new RestClient(idAddress + "/connect/token");
            client.Timeout = -1;
            var request = new RestRequest(Method.POST);
            request.AddHeader("Content-Type", "application/x-www-form-urlencoded");
            request.AddHeader("Cookie", ".AspNetCore.Antiforgery.vjuewlBzmtY=CfDJ8Kv7Ggl5zF9LtTRDshJ6tN5DGiP6C-qI56XsVKzz3fDDepwMerOS293mI-4i7ejVk0gRA_1PXzg772Wh8GhEa6fwRGEDrSIP0itGK16n5KPmrL99Jzn-n2GUUnnXZDofDxn0_GMHbCloQUIlcSlBmfY; 3f6bf69972563c3e0e619b78edf73035=21e804229703382fb01b646444836a46");
            request.AddParameter("grant_type", "client_credentials");
            request.AddParameter("client_id", userId);
            request.AddParameter("client_secret", userSecret);
            request.AddParameter("scope", "InvoicingAPI");
            IRestResponse response = client.Execute(request);


            try
            {
                var obj = JsonConvert.DeserializeObject<LoginModelResponse>(response.Content);

                //Program.token = obj.AccessToken;
                return obj.AccessToken;
            }
            catch
            {
                return "Error With Connection Try Again";
            }

        }


        public string GetDocumentTypes()
        {
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Ssl3 | SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;

            var client = new RestClient("https://api.invoicing.eta.gov.eg/api/v1/documenttypes");
            client.Timeout = -1;
            var request = new RestRequest(Method.GET);
            request.AddHeader("Accept-Language", "ar");
            request.AddHeader("Authorization", "Bearer " + token);
            request.AddHeader("Content-Type", "application/json");
            request.AddHeader("Cookie", "75fd0698a2e84d6b8a3cb94ae54530f3=1f4c16eb0e08ebc49a41b5616e623f5c");
            request.AddParameter("documentTypeCodeName", "creditupdated");
            request.AddParameter("namePrimaryLang", "CreditEn");
            request.AddParameter("nameSecondaryLang", "CreditAr");
            request.AddParameter("descriptionPrimaryLang", "Des-creditEn");
            request.AddParameter("descriptionSecondaryLang", "Des-creditAr");

            IRestResponse response = client.Execute(request);

            //var obj =  JsonConvert.DeserializeObject<SubmitDocument>(response.Content);

            if (response.Content == "")
            {
                return "";
            }
            else
            {
                // MessageBox.Show(response.Content);
                return response.Content;
            }
        }

        public string GetDocumentType(string id)
        {
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Ssl3 | SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;

            var client = new RestClient(@"https://api.invoicing.eta.gov.eg/api/v1/documenttypes/" + id);
            client.Timeout = -1;
            var request = new RestRequest(Method.GET);
            request.AddHeader("Authorization", "Bearer " + token);
            request.AddHeader("Cookie", "75fd0698a2e84d6b8a3cb94ae54530f3=1e9645b04c7a5910b93f44425ddff185");
            var body = @"";
            request.AddParameter("text/plain", body, ParameterType.RequestBody);
            IRestResponse response = client.Execute(request);

            if (response.Content == "")
            {
                return "";
            }
            else
            {
                return response.Content;
            }
        }

        public string GetDocumentTypeByIdAndVersion(string id, string version)
        {
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Ssl3 | SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;
            string uri = string.Format("https://api.invoicing.eta.gov.eg/api/v1/documenttypes/{0}/versions/{1}", id, version);
            var client = new RestClient(uri);
            client.Timeout = -1;
            var request = new RestRequest(Method.GET);
            request.AddHeader("Accept-Language", "ar");
            request.AddHeader("Authorization", "Bearer " + token);
            request.AddHeader("Cookie", "TS016706db=01bb6af84e4eaa5adc93d76f8fba14f5d4e55bfc24ff807ecb2a99b9191f4f97e608fc25e8ddf9f55697f479ae01d24980791f877b488522e6cb6c8d791962864414ed8e24; dtCookie=v_4_srv_6_sn_375856A2ED5867F588C22C8B51F3D960_perc_100000_ol_0_mul_1_app-3Aea7c4b59f27d43eb_0_rcs-3Acss_0; 3f6bf69972563c3e0e619b78edf73035=9baff2bd48789a4e3a93f71517a70bb5; COOKIE=!20wqfPQsq3VceWYXeBsDsm8BwNYKFKzjRZdpFkhYItP2gOV90xueBS3RCVCKYmjDIX1tVYv7aPl/TWs=");
            var body = @"";
            request.AddParameter("text/plain", body, ParameterType.RequestBody);
            IRestResponse response = client.Execute(request);


            return response.Content;


        }

        public string SubmitDocument()
        {
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Ssl3 | SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;
            var client = new RestClient("https://api.invoicing.eta.gov.eg/api/v1/documentsubmissions");
            client.Timeout = -1;
            var request = new RestRequest(Method.POST);
            request.AddHeader("Content-Type", "application/json");
            request.AddHeader("Authorization", "Bearer " + token);
            request.AddHeader("Cookie", "TS016706db=01bb6af84e4eaa5adc93d76f8fba14f5d4e55bfc24ff807ecb2a99b9191f4f97e608fc25e8ddf9f55697f479ae01d24980791f877b488522e6cb6c8d791962864414ed8e24; dtCookie=v_4_srv_6_sn_375856A2ED5867F588C22C8B51F3D960_perc_100000_ol_0_mul_1_app-3Aea7c4b59f27d43eb_0_rcs-3Acss_0; 3f6bf69972563c3e0e619b78edf73035=9baff2bd48789a4e3a93f71517a70bb5; COOKIE=!20wqfPQsq3VceWYXeBsDsm8BwNYKFKzjRZdpFkhYItP2gOV90xueBS3RCVCKYmjDIX1tVYv7aPl/TWs=");
            var body = @"{
" + "\n" +
@"    ""documents"": [
" + "\n" +
@"        {
" + "\n" +
@"            ""issuer"": {
" + "\n" +
@"                ""address"": {
" + "\n" +
@"                    ""branchID"": ""0"",
" + "\n" +
@"                    ""country"": ""EG"",
" + "\n" +
@"                    ""governate"": ""Cairo"",
" + "\n" +
@"                    ""regionCity"": ""Nasr City"",
" + "\n" +
@"                    ""street"": ""580 Clementina Key"",
" + "\n" +
@"                    ""buildingNumber"": ""Bldg. 0"",
" + "\n" +
@"                    ""postalCode"": ""68030"",
" + "\n" +
@"                    ""floor"": ""1"",
" + "\n" +
@"                    ""room"": ""123"",
" + "\n" +
@"                    ""landmark"": ""7660 Melody Trail"",
" + "\n" +
@"                    ""additionalInformation"": ""beside Townhall""
" + "\n" +
@"                },
" + "\n" +
@"                ""type"": ""B"",
" + "\n" +
@"                ""id"": ""58446674"",
" + "\n" +
@"                ""name"": ""Issuer Company""
" + "\n" +
@"            },
" + "\n" +
@"            ""receiver"": {
" + "\n" +
@"                ""address"": {
" + "\n" +
@"                    ""country"": ""EG"",
" + "\n" +
@"                    ""governate"": ""Egypt"",
" + "\n" +
@"                    ""regionCity"": ""Mufazat al Ismlyah"",
" + "\n" +
@"                    ""street"": ""580 Clementina Key"",
" + "\n" +
@"                    ""buildingNumber"": ""Bldg. 0"",
" + "\n" +
@"                    ""postalCode"": ""68030"",
" + "\n" +
@"                    ""floor"": ""1"",
" + "\n" +
@"                    ""room"": ""123"",
" + "\n" +
@"                    ""landmark"": ""7660 Melody Trail"",
" + "\n" +
@"                    ""additionalInformation"": ""beside Townhall""
" + "\n" +
@"                },
" + "\n" +
@"                ""type"": ""B"",
" + "\n" +
@"                ""id"": ""313717919"",
" + "\n" +
@"                ""name"": ""Receiver""
" + "\n" +
@"            },
" + "\n" +
@"            ""documentType"": ""I"",
" + "\n" +
@"            ""documentTypeVersion"": ""1.0"",
" + "\n" +
@"            ""dateTimeIssued"": ""2021-02-07T02:04:45Z"",
" + "\n" +
@"            ""taxpayerActivityCode"": ""4620"",
" + "\n" +
@"            ""internalID"": ""IID1"",
" + "\n" +
@"            ""purchaseOrderReference"": ""P-233-A6375"",
" + "\n" +
@"            ""purchaseOrderDescription"": ""purchase Order description"",
" + "\n" +
@"            ""salesOrderReference"": ""1231"",
" + "\n" +
@"            ""salesOrderDescription"": ""Sales Order description"",
" + "\n" +
@"            ""proformaInvoiceNumber"": ""SomeValue"",
" + "\n" +
@"            ""payment"": {
" + "\n" +
@"                ""bankName"": ""SomeValue"",
" + "\n" +
@"                ""bankAddress"": ""SomeValue"",
" + "\n" +
@"                ""bankAccountNo"": ""SomeValue"",
" + "\n" +
@"                ""bankAccountIBAN"": """",
" + "\n" +
@"                ""swiftCode"": """",
" + "\n" +
@"                ""terms"": ""SomeValue""
" + "\n" +
@"            },
" + "\n" +
@"            ""delivery"": {
" + "\n" +
@"                ""approach"": ""SomeValue"",
" + "\n" +
@"                ""packaging"": ""SomeValue"",
" + "\n" +
@"                ""dateValidity"": ""2020-09-28T09:30:10Z"",
" + "\n" +
@"                ""exportPort"": ""SomeValue"",
" + "\n" +
@"                ""grossWeight"": 10.50,
" + "\n" +
@"                ""netWeight"": 20.50,
" + "\n" +
@"                ""terms"": ""SomeValue""
" + "\n" +
@"            },
" + "\n" +
@"            ""invoiceLines"": [
" + "\n" +
@"                {
" + "\n" +
@"                    ""description"": ""Computer1"",
" + "\n" +
@"                    ""itemType"": ""EGS"",
" + "\n" +
@"                    ""itemCode"": ""EG-113317713-123456"",
" + "\n" +
@"                    ""unitType"": ""EA"",
" + "\n" +
@"                    ""quantity"": 1,
" + "\n" +
@"                    ""internalCode"": ""IC0"",
" + "\n" +
@"                    ""salesTotal"": 111111111111.00,
" + "\n" +
@"                    ""total"": 111111111111.00,
" + "\n" +
@"                    ""valueDifference"": 0.00,
" + "\n" +
@"                    ""totalTaxableFees"": 0,
" + "\n" +
@"                    ""netTotal"": 111111111111,
" + "\n" +
@"                    ""itemsDiscount"": 0,
" + "\n" +
@"                    ""unitValue"": {
" + "\n" +
@"                        ""currencySold"": ""EGP"",
" + "\n" +
@"                        ""amountEGP"": 111111111111.00
" + "\n" +
@"                    },
" + "\n" +
@"                    ""discount"": {
" + "\n" +
@"                        ""rate"": 0,
" + "\n" +
@"                        ""amount"": 0
" + "\n" +
@"                    },
" + "\n" +
@"                    ""taxableItems"": [
" + "\n" +
@"                        {
" + "\n" +
@"                            ""taxType"": ""T1"",
" + "\n" +
@"                            ""amount"": 0,
" + "\n" +
@"                            ""subType"": ""V001"",
" + "\n" +
@"                            ""rate"": 0
" + "\n" +
@"                        }
" + "\n" +
@"                    ]
" + "\n" +
@"                },
" + "\n" +
@"                {
" + "\n" +
@"                    ""description"": ""Computer1"",
" + "\n" +
@"                    ""itemType"": ""EGS"",
" + "\n" +
@"                    ""itemCode"": ""EG-113317713-123456"",
" + "\n" +
@"                    ""unitType"": ""EA"",
" + "\n" +
@"                    ""quantity"": 1,
" + "\n" +
@"                    ""internalCode"": ""IC0"",
" + "\n" +
@"                    ""salesTotal"": 111111111111.00,
" + "\n" +
@"                    ""total"": 111111111111.00,
" + "\n" +
@"                    ""valueDifference"": 0.00,
" + "\n" +
@"                    ""totalTaxableFees"": 0,
" + "\n" +
@"                    ""netTotal"": 111111111111,
" + "\n" +
@"                    ""itemsDiscount"": 0,
" + "\n" +
@"                    ""unitValue"": {
" + "\n" +
@"                        ""currencySold"": ""EGP"",
" + "\n" +
@"                        ""amountEGP"": 111111111111.00
" + "\n" +
@"                    },
" + "\n" +
@"                    ""discount"": {
" + "\n" +
@"                        ""rate"": 0,
" + "\n" +
@"                        ""amount"": 0
" + "\n" +
@"                    },
" + "\n" +
@"                    ""taxableItems"": [
" + "\n" +
@"                        {
" + "\n" +
@"                            ""taxType"": ""T1"",
" + "\n" +
@"                            ""amount"": 0,
" + "\n" +
@"                            ""subType"": ""V001"",
" + "\n" +
@"                            ""rate"": 0
" + "\n" +
@"                        }
" + "\n" +
@"                    ]
" + "\n" +
@"                },
" + "\n" +
@"                {
" + "\n" +
@"                    ""description"": ""Computer1"",
" + "\n" +
@"                    ""itemType"": ""EGS"",
" + "\n" +
@"                    ""itemCode"": ""EG-113317713-123456"",
" + "\n" +
@"                    ""unitType"": ""EA"",
" + "\n" +
@"                    ""quantity"": 1,
" + "\n" +
@"                    ""internalCode"": ""IC0"",
" + "\n" +
@"                    ""salesTotal"": 111111111111.00,
" + "\n" +
@"                    ""total"": 111111111111.00,
" + "\n" +
@"                    ""valueDifference"": 0.00,
" + "\n" +
@"                    ""totalTaxableFees"": 0,
" + "\n" +
@"                    ""netTotal"": 111111111111,
" + "\n" +
@"                    ""itemsDiscount"": 0,
" + "\n" +
@"                    ""unitValue"": {
" + "\n" +
@"                        ""currencySold"": ""EGP"",
" + "\n" +
@"                        ""amountEGP"": 111111111111.00
" + "\n" +
@"                    },
" + "\n" +
@"                    ""discount"": {
" + "\n" +
@"                        ""rate"": 0,
" + "\n" +
@"                        ""amount"": 0
" + "\n" +
@"                    },
" + "\n" +
@"                    ""taxableItems"": [
" + "\n" +
@"                        {
" + "\n" +
@"                            ""taxType"": ""T1"",
" + "\n" +
@"                            ""amount"": 0,
" + "\n" +
@"                            ""subType"": ""V001"",
" + "\n" +
@"                            ""rate"": 0
" + "\n" +
@"                        }
" + "\n" +
@"                    ]
" + "\n" +
@"                },
" + "\n" +
@"                {
" + "\n" +
@"                    ""description"": ""Computer1"",
" + "\n" +
@"                    ""itemType"": ""EGS"",
" + "\n" +
@"                    ""itemCode"": ""EG-113317713-123456"",
" + "\n" +
@"                    ""unitType"": ""EA"",
" + "\n" +
@"                    ""quantity"": 1,
" + "\n" +
@"                    ""internalCode"": ""IC0"",
" + "\n" +
@"                    ""salesTotal"": 111111111111.00,
" + "\n" +
@"                    ""total"": 111111111111.00,
" + "\n" +
@"                    ""valueDifference"": 0.00,
" + "\n" +
@"                    ""totalTaxableFees"": 0,
" + "\n" +
@"                    ""netTotal"": 111111111111,
" + "\n" +
@"                    ""itemsDiscount"": 0,
" + "\n" +
@"                    ""unitValue"": {
" + "\n" +
@"                        ""currencySold"": ""EGP"",
" + "\n" +
@"                        ""amountEGP"": 111111111111.00
" + "\n" +
@"                    },
" + "\n" +
@"                    ""discount"": {
" + "\n" +
@"                        ""rate"": 0,
" + "\n" +
@"                        ""amount"": 0
" + "\n" +
@"                    },
" + "\n" +
@"                    ""taxableItems"": [
" + "\n" +
@"                        {
" + "\n" +
@"                            ""taxType"": ""T1"",
" + "\n" +
@"                            ""amount"": 0,
" + "\n" +
@"                            ""subType"": ""V001"",
" + "\n" +
@"                            ""rate"": 0
" + "\n" +
@"                        }
" + "\n" +
@"                    ]
" + "\n" +
@"                },
" + "\n" +
@"                {
" + "\n" +
@"                    ""description"": ""Computer1"",
" + "\n" +
@"                    ""itemType"": ""EGS"",
" + "\n" +
@"                    ""itemCode"": ""EG-113317713-123456"",
" + "\n" +
@"                    ""unitType"": ""EA"",
" + "\n" +
@"                    ""quantity"": 1,
" + "\n" +
@"                    ""internalCode"": ""IC0"",
" + "\n" +
@"                    ""salesTotal"": 111111111111.00,
" + "\n" +
@"                    ""total"": 111111111111.00,
" + "\n" +
@"                    ""valueDifference"": 0.00,
" + "\n" +
@"                    ""totalTaxableFees"": 0,
" + "\n" +
@"                    ""netTotal"": 111111111111,
" + "\n" +
@"                    ""itemsDiscount"": 0,
" + "\n" +
@"                    ""unitValue"": {
" + "\n" +
@"                        ""currencySold"": ""EGP"",
" + "\n" +
@"                        ""amountEGP"": 111111111111.00
" + "\n" +
@"                    },
" + "\n" +
@"                    ""discount"": {
" + "\n" +
@"                        ""rate"": 0,
" + "\n" +
@"                        ""amount"": 0
" + "\n" +
@"                    },
" + "\n" +
@"                    ""taxableItems"": [
" + "\n" +
@"                        {
" + "\n" +
@"                            ""taxType"": ""T1"",
" + "\n" +
@"                            ""amount"": 0,
" + "\n" +
@"                            ""subType"": ""V001"",
" + "\n" +
@"                            ""rate"": 0
" + "\n" +
@"                        }
" + "\n" +
@"                    ]
" + "\n" +
@"                }
" + "\n" +
@"            ],
" + "\n" +
@"            ""totalDiscountAmount"": 0,
" + "\n" +
@"            ""totalSalesAmount"": 555555555555.00,
" + "\n" +
@"            ""netAmount"": 555555555555.00,
" + "\n" +
@"            ""taxTotals"": [
" + "\n" +
@"                {
" + "\n" +
@"                    ""taxType"": ""T1"",
" + "\n" +
@"                    ""amount"": 0
" + "\n" +
@"                }
" + "\n" +
@"            ],
" + "\n" +
@"            ""totalAmount"": 555555555555.00,
" + "\n" +
@"            ""extraDiscountAmount"": 0,
" + "\n" +
@"            ""totalItemsDiscountAmount"": 0,
" + "\n" +
@"            ""signatures"": [
" + "\n" +
@"                {
" + "\n" +
@"                    ""signatureType"": ""I"",
" + "\n" +
@"                    ""value"": ""MIIGywYJKoZIhvcNAQcCoIIGvDCCBrgCAQMxDTALBglghkgBZQMEAgEwCwYJKoZIhvcNAQcFoIID/zCCA/swggLjoAMCAQICEEFkOqRVlVar0F0n3FZOLiIwDQYJKoZIhvcNAQELBQAwSTELMAkGA1UEBhMCRUcxFDASBgNVBAoTC0VneXB0IFRydXN0MSQwIgYDVQQDExtFZ3lwdCBUcnVzdCBDb3Jwb3JhdGUgQ0EgRzIwHhcNMjAwMzMxMDAwMDAwWhcNMjEwMzMwMjM1OTU5WjBgMRUwEwYDVQQKFAxFZ3lwdCBUcnVzdCAxGDAWBgNVBGEUD1ZBVEVHLTExMzMxNzcxMzELMAkGA1UEBhMCRUcxIDAeBgNVBAMMF1Rlc3QgU2VhbGluZyBEZW1vIHVzZXIyMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEApmVGVJtpImeq\u002BtIJiVWSkIEEOTIcnG1XNYQOYtf5\u002BDg9eF5H5x1wkgR2G7dvWVXrTsdNv2Q\u002Bgvml9SdfWxlYxaljg2AuBrsHFjYVEAQFI37EW2K7tbMT7bfxwT1M5tbjxnkTTK12cgwxPr2LBNhHpfXp8SNyWCxpk6eyJb87DveVwCLbAGGXO9mhDj62glVTrCFit7mHC6bZ6MOMAp013B8No9c8xnrKQiOb4Tm2GxBYHFwEcfYUGZNltGZNdVUtu6ty\u002BNTrSRRC/dILeGHgz6/2pgQPk5OFYRTRHRNVNo\u002BjG\u002BnurUYkSWxA4I9CmsVt2FdeBeuvRFs/U1I\u002BieKg1wIDAQABo4HHMIHEMAkGA1UdEwQCMAAwVAYDVR0fBE0wSzBJoEegRYZDaHR0cDovL21wa2ljcmwuZWd5cHR0cnVzdC5jb20vRWd5cHRUcnVzdENvcnBvcmF0ZUNBRzIvTGF0ZXN0Q1JMLmNybDAdBgNVHQ4EFgQUqzFDImtytsUbghbmtnl2/k4d5jEwEQYJYIZIAYb4QgEBBAQDAgeAMB8GA1UdIwQYMBaAFCInP8ziUIPmu86XJUWXspKN3LsFMA4GA1UdDwEB/wQEAwIGwDANBgkqhkiG9w0BAQsFAAOCAQEAxE3KpyYlPy/e3\u002B6jfz5RqlLhRLppWpRlKYUvH1uIhCNRuWaYYRchw1xe3jn7bLKbNrUmey\u002BMRwp1hZptkxFMYKTIEnNjOKCrLmVIuPFcfLXAQFq5vgLDSbnUhG/r5D\u002B50ndPucyUPhX3gw8gFlA1R\u002BtdNEoeKqYSo9v3p5qNANq12OuZbkhPg6sAD4dojWoNdlkc8J2ML0eq4a5AQvb4yZVb\u002BezqJyqKj83RekRZi0kMxoIm8l82CN8I/Bmp6VVNJRhQKhSeb7ShpdkZcMwcfKdDw6LW02/XcmzVl8NBBbLjKSJ/jxdL1RxPPza7RbGqSx9pfyav5\u002BAxO9sXnXXc5jGCApIwggKOAgEBMF0wSTELMAkGA1UEBhMCRUcxFDASBgNVBAoTC0VneXB0IFRydXN0MSQwIgYDVQQDExtFZ3lwdCBUcnVzdCBDb3Jwb3JhdGUgQ0EgRzICEEFkOqRVlVar0F0n3FZOLiIwCwYJYIZIAWUDBAIBoIIBCjAYBgkqhkiG9w0BCQMxCwYJKoZIhvcNAQcFMBwGCSqGSIb3DQEJBTEPFw0yMTAyMDEyMzUwMjFaMC8GCSqGSIb3DQEJBDEiBCD5bGXJu9uJZIPMGXK98UrHzJM/V2U/WAO6BErxpX5wdTCBngYLKoZIhvcNAQkQAi8xgY4wgYswgYgwgYUEIAJA8uO/ek3l9i3ZOgRtPhGWwwFYljbeJ7yAgEnyYNCWMGEwTaBLMEkxCzAJBgNVBAYTAkVHMRQwEgYDVQQKEwtFZ3lwdCBUcnVzdDEkMCIGA1UEAxMbRWd5cHQgVHJ1c3QgQ29ycG9yYXRlIENBIEcyAhBBZDqkVZVWq9BdJ9xWTi4iMAsGCSqGSIb3DQEBAQSCAQB13E1WX\u002BzbWppfJi3DBK9MMSB1TXuxcNkGXQ19OcRUUAaAe2K\u002BisobYrUCZbi3ygc2AWOMyafboxjjomzrnvXKrFgspT4wAFPYaAGFzKWq\u002BW/nqMhIqJVIpS/NM7Al4HvuBA5iGuZEQFusElB0yIxOIiYDI4v8Ilkff4/duj/V2CNaN5cqXLOpL5RP6Y5i\u002BVsPGb89t/L0dSIldGN0JqaqarqYo5/RwsUFJJq01DFpPGNbOIX3gSCDmycfhJPS9csnne9Zt\u002BabNpja5ZR6KA8JMe4DHes7FDZqHBNHdC\u002BRDXT4crqmnyiJjizULu6MqDc0Fv3vrMMWDLRlwDecgq7i""
" + "\n" +
@"                }
" + "\n" +
@"            ]
" + "\n" +
@"        }
" + "\n" +
@"    ]
" + "\n" +
@"}";
            request.AddParameter("application/json", body, ParameterType.RequestBody);
            IRestResponse response = client.Execute(request);


            return response.Content;

        }

        public string GetRecentDocument()
        {
            var client = new RestClient("https://api.invoicing.eta.gov.eg/api/v1.0/documents/recent");
            client.Timeout = -1;
            var request = new RestRequest(Method.GET);
            request.AddHeader("PageSize", "10");
            request.AddHeader("PageNo", "1");
            request.AddHeader("Authorization", "Bearer " + token);
            request.AddHeader("Cookie", "TS016706db=01bb6af84e4eaa5adc93d76f8fba14f5d4e55bfc24ff807ecb2a99b9191f4f97e608fc25e8ddf9f55697f479ae01d24980791f877b488522e6cb6c8d791962864414ed8e24; dtCookie=v_4_srv_6_sn_375856A2ED5867F588C22C8B51F3D960_perc_100000_ol_0_mul_1_app-3Aea7c4b59f27d43eb_0_rcs-3Acss_0; 3f6bf69972563c3e0e619b78edf73035=9baff2bd48789a4e3a93f71517a70bb5; COOKIE=!20wqfPQsq3VceWYXeBsDsm8BwNYKFKzjRZdpFkhYItP2gOV90xueBS3RCVCKYmjDIX1tVYv7aPl/TWs=");
            IRestResponse response = client.Execute(request);


            return response.Content;
        }
    }
}