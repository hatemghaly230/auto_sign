﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutoSigner.Models
{
    public class SubmitDocumentResponse
    {
        [JsonProperty("submissionId")]
        public object SubmissionId { get; set; }

        [JsonProperty("acceptedDocuments")]
        public List<AcceptedDocuments> AcceptedDocuments { get; set; }

        [JsonProperty("rejectedDocuments")]
        public List<RejectedDocument> RejectedDocuments { get; set; }

    }
    public class RejectedDocument
    {
        [JsonProperty("internalId")]
        public string InternalId { get; set; }

        [JsonProperty("error")]
        public Error2 Error { get; set; }
    }

    public class AcceptedDocuments
    {
        [JsonProperty("uuid")]
        public string UUID { get; set; }
        [JsonProperty("longId")]
        public string LongId { get; set; }
        [JsonProperty("internalId")]
        public string InternalId { get; set; }
    }
    public class Error2
    {
        [JsonProperty("code")]
        public string Code { get; set; }

        [JsonProperty("message")]
        public string Message { get; set; }

        [JsonProperty("target")]
        public string Target { get; set; }

        [JsonProperty("propertyPath")]
        public object PropertyPath { get; set; }

        [JsonProperty("details")]
        public List<Detail> Details { get; set; }
    }

    public class Detail
    {
        [JsonProperty("code")]
        public string Code { get; set; }

        [JsonProperty("message")]
        public string Message { get; set; }

        [JsonProperty("target")]
        public string Target { get; set; }

        [JsonProperty("propertyPath")]
        public string PropertyPath { get; set; }

        [JsonProperty("details")]
        public object Details { get; set; }
    }

}
