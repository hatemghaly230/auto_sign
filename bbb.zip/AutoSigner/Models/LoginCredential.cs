﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutoSigner.Models
{
    public class LoginCredential
    {
        public string apiBaseUrl { get; set; }
        public string idSrvBaseUrl { get; set; }
        public string clientId { get; set; }
        public string clientSecret { get; set; }

    }
}
