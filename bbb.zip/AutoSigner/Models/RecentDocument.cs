﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutoSigner.Models
{
    public  class RecentDocument
    {
        [JsonProperty("result")]
        public List<DocumentData> Result { get; set; }

        [JsonProperty("metadata")]
        public Metadata Metadata { get; set; }
    }
    public class DocumentData
    {
        [JsonProperty("publicUrl")]
        public string PublicUrl { get; set; }

        [JsonProperty("uuid")]
        public string Uuid { get; set; }

        [JsonProperty("submissionUUID")]
        public string SubmissionUUID { get; set; }

        [JsonProperty("longId")]
        public string LongId { get; set; }

        [JsonProperty("internalId")]
        public string InternalId { get; set; }

        [JsonProperty("typeName")]
        public string TypeName { get; set; }

        [JsonProperty("documentTypeNamePrimaryLang")]
        public string DocumentTypeNamePrimaryLang { get; set; }

        [JsonProperty("documentTypeNameSecondaryLang")]
        public string DocumentTypeNameSecondaryLang { get; set; }

        [JsonProperty("typeVersionName")]
        public string TypeVersionName { get; set; }

        [JsonProperty("issuerId")]
        public string IssuerId { get; set; }

        [JsonProperty("issuerName")]
        public string IssuerName { get; set; }

        [JsonProperty("receiverId")]
        public string ReceiverId { get; set; }

        [JsonProperty("receiverName")]
        public string ReceiverName { get; set; }

        [JsonProperty("dateTimeIssued")]
        public DateTime DateTimeIssued { get; set; }

        [JsonProperty("dateTimeReceived")]
        public DateTime DateTimeReceived { get; set; }

        [JsonProperty("totalSales")]
        public double TotalSales { get; set; }

        [JsonProperty("totalDiscount")]
        public double TotalDiscount { get; set; }

        [JsonProperty("netAmount")]
        public double NetAmount { get; set; }

        [JsonProperty("total")]
        public double Total { get; set; }

        [JsonProperty("maxPercision")]
        public int MaxPercision { get; set; }

        [JsonProperty("invoiceLineItemCodes")]
        public object InvoiceLineItemCodes { get; set; }

        [JsonProperty("cancelRequestDate")]
        public object CancelRequestDate { get; set; }

        [JsonProperty("rejectRequestDate")]
        public object RejectRequestDate { get; set; }

        [JsonProperty("cancelRequestDelayedDate")]
        public object CancelRequestDelayedDate { get; set; }

        [JsonProperty("rejectRequestDelayedDate")]
        public object RejectRequestDelayedDate { get; set; }

        [JsonProperty("declineCancelRequestDate")]
        public object DeclineCancelRequestDate { get; set; }

        [JsonProperty("declineRejectRequestDate")]
        public object DeclineRejectRequestDate { get; set; }

        [JsonProperty("documentStatusReason")]
        public string DocumentStatusReason { get; set; }

        [JsonProperty("status")]
        public string Status { get; set; }

        [JsonProperty("createdByUserId")]
        public string CreatedByUserId { get; set; }
    }

    public class Metadata
    {
        [JsonProperty("totalPages")]
        public int TotalPages { get; set; }

        [JsonProperty("totalCount")]
        public int TotalCount { get; set; }
    }


}
