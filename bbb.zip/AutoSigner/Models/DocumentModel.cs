﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutoSigner.Models
{
    // Root myDeserializedClass = JsonConvert.DeserializeObject<Root>(myJsonResponse); 
    public class Address
    {
        [JsonProperty("branchID")]
        public string BranchID { get; set; }

        [JsonProperty("country")]
        public string Country { get; set; }

        [JsonProperty("governate")]
        public string Governate { get; set; }

        [JsonProperty("regionCity")]
        public string RegionCity { get; set; }

        [JsonProperty("street")]
        public string Street { get; set; }

        [JsonProperty("buildingNumber")]
        public string BuildingNumber { get; set; }

        [JsonProperty("postalCode")]
        public string PostalCode { get; set; }

        [JsonProperty("floor")]
        public string Floor { get; set; }

        [JsonProperty("room")]
        public string Room { get; set; }

        [JsonProperty("landmark")]
        public string Landmark { get; set; }

        [JsonProperty("additionalInformation")]
        public string AdditionalInformation { get; set; }
    }

    public class Issuer
    {
        [JsonProperty("address")]
        public Address Address { get; set; }

        [JsonProperty("type")]
        public string Type { get; set; }

        [JsonProperty("id")]
        public string Id { get; set; }

        [JsonProperty("name")]
        public string Name { get; set; }
    }

    public class Receiver
    {
        [JsonProperty("address")]
        public Address Address { get; set; }

        [JsonProperty("type")]
        public string Type { get; set; }

        [JsonProperty("id")]
        public string Id { get; set; }

        [JsonProperty("name")]
        public string Name { get; set; }
    }

    public class Payment
    {
        [JsonProperty("bankName")]
        public string BankName { get; set; }

        [JsonProperty("bankAddress")]
        public string BankAddress { get; set; }

        [JsonProperty("bankAccountNo")]
        public string BankAccountNo { get; set; }

        [JsonProperty("bankAccountIBAN")]
        public string BankAccountIBAN { get; set; }

        [JsonProperty("swiftCode")]
        public string SwiftCode { get; set; }

        [JsonProperty("terms")]
        public string Terms { get; set; }
    }

    public class Delivery
    {
        [JsonProperty("approach")]
        public string Approach { get; set; }

        [JsonProperty("packaging")]
        public string Packaging { get; set; }

        [JsonProperty("dateValidity")]
        public DateTime DateValidity { get; set; }

        [JsonProperty("exportPort")]
        public string ExportPort { get; set; }

        [JsonProperty("countryOfOrigin")]
        public string CountryOfOrigin { get; set; }

        [JsonProperty("grossWeight")]
        public double GrossWeight { get; set; }

        [JsonProperty("netWeight")]
        public double NetWeight { get; set; }

        [JsonProperty("terms")]
        public string Terms { get; set; }
    }

    public class UnitValue
    {
        [JsonProperty("currencySold")]
        public string CurrencySold { get; set; }

        [JsonProperty("amountEGP")]
        public double AmountEGP { get; set; }

        [JsonProperty("amountSold")]
        public double AmountSold { get; set; }

        [JsonProperty("currencyExchangeRate")]
        public double CurrencyExchangeRate { get; set; }
    }

    public class Discount
    {
        [JsonProperty("rate")]
        public int Rate { get; set; }

        [JsonProperty("amount")]
        public double Amount { get; set; }
    }

    public class TaxableItem
    {
        [JsonProperty("taxType")]
        public string TaxType { get; set; }

        [JsonProperty("amount")]
        public double Amount { get; set; }

        [JsonProperty("subType")]
        public string SubType { get; set; }

        [JsonProperty("rate")]
        public double Rate { get; set; }
    }

    public class InvoiceLine
    {
        [JsonProperty("description")]
        public string Description { get; set; }

        [JsonProperty("itemType")]
        public string ItemType { get; set; }

        [JsonProperty("itemCode")]
        public string ItemCode { get; set; }

        [JsonProperty("unitType")]
        public string UnitType { get; set; }

        [JsonProperty("quantity")]
        public int Quantity { get; set; }

        [JsonProperty("internalCode")]
        public string InternalCode { get; set; }

        [JsonProperty("salesTotal")]
        public double SalesTotal { get; set; }

        [JsonProperty("total")]
        public double Total { get; set; }

        [JsonProperty("valueDifference")]
        public double ValueDifference { get; set; }

        [JsonProperty("totalTaxableFees")]
        public double TotalTaxableFees { get; set; }

        [JsonProperty("netTotal")]
        public double NetTotal { get; set; }

        [JsonProperty("itemsDiscount")]
        public double ItemsDiscount { get; set; }

        [JsonProperty("unitValue")]
        public UnitValue UnitValue { get; set; }

        [JsonProperty("discount")]
        public Discount Discount { get; set; }

        [JsonProperty("taxableItems")]
        public List<TaxableItem> TaxableItems { get; set; }
    }

    public class TaxTotal
    {
        [JsonProperty("taxType")]
        public string TaxType { get; set; }

        [JsonProperty("amount")]
        public double Amount { get; set; }
    }

    public class DocumentModel
    {
        [JsonProperty("issuer")]
        public Issuer Issuer { get; set; }

        [JsonProperty("receiver")]
        public Receiver Receiver { get; set; }

        [JsonProperty("documentType")]
        public string DocumentType { get; set; }

        [JsonProperty("documentTypeVersion")]
        public string DocumentTypeVersion { get; set; }

        [JsonProperty("dateTimeIssued")]
        public DateTime DateTimeIssued { get; set; }

        [JsonProperty("taxpayerActivityCode")]
        public string TaxpayerActivityCode { get; set; }

        [JsonProperty("internalID")]
        public string InternalID { get; set; }

        [JsonProperty("purchaseOrderReference")]
        public string PurchaseOrderReference { get; set; }

        [JsonProperty("purchaseOrderDescription")]
        public string PurchaseOrderDescription { get; set; }

        [JsonProperty("salesOrderReference")]
        public string SalesOrderReference { get; set; }

        [JsonProperty("salesOrderDescription")]
        public string SalesOrderDescription { get; set; }

        [JsonProperty("proformaInvoiceNumber")]
        public string ProformaInvoiceNumber { get; set; }

        [JsonProperty("payment")]
        public Payment Payment { get; set; }

        [JsonProperty("delivery")]
        public Delivery Delivery { get; set; }

        [JsonProperty("invoiceLines")]
        public List<InvoiceLine> InvoiceLines { get; set; }

        [JsonProperty("totalDiscountAmount")]
        public double TotalDiscountAmount { get; set; }

        [JsonProperty("totalSalesAmount")]
        public double TotalSalesAmount { get; set; }

        [JsonProperty("netAmount")]
        public double NetAmount { get; set; }

        [JsonProperty("taxTotals")]
        public List<TaxTotal> TaxTotals { get; set; }

        [JsonProperty("totalAmount")]
        public double TotalAmount { get; set; }

        [JsonProperty("extraDiscountAmount")]
        public double ExtraDiscountAmount { get; set; }

        [JsonProperty("totalItemsDiscountAmount")]
        public double TotalItemsDiscountAmount { get; set; }
    }


}
