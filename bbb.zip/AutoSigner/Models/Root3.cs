﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutoSigner.Models
{

    // Root myDeserializedClass = JsonConvert.DeserializeObject<Root>(myJsonResponse); 
    public class Root3
    {
        [JsonProperty("code")]
        public string Code { get; set; }

        [JsonProperty("Desc_en")]
        public string DescEn { get; set; }

        [JsonProperty("Desc_ar")]
        public string DescAr { get; set; }



    }
}
