﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutoSigner.Models
{
    public class DocumentTypeByIdAndVersion
    {
  
        [JsonProperty("typeName")]
        public string TypeName { get; set; }

        [JsonProperty("name")]
        public string Name { get; set; }

        [JsonProperty("description")]
        public string Description { get; set; }

        [JsonProperty("versionNumber")]
        public string VersionNumber { get; set; }

        [JsonProperty("jsonschema")]
        public string Jsonschema { get; set; }

        [JsonProperty("xmlschema")]
        public string Xmlschema { get; set; }

        [JsonProperty("status")]
        public string Status { get; set; }

        [JsonProperty("activeFrom")]
        public DateTime ActiveFrom { get; set; }

        [JsonProperty("activeTo")]
        public object ActiveTo { get; set; }

        [JsonProperty("error")]
        public Error Error { get; set; }
    }


}
