﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutoSigner.Models
{

    // Root myDeserializedClass = JsonConvert.DeserializeObject<Root>(myJsonResponse); 
    public class DocumentTypeVersion2
    {
        [JsonProperty("id")]
        public int Id { get; set; }

        [JsonProperty("typeName")]
        public string TypeName { get; set; }

        [JsonProperty("name")]
        public string Name { get; set; }

        [JsonProperty("description")]
        public string Description { get; set; }

        [JsonProperty("versionNumber")]
        public string VersionNumber { get; set; }

        [JsonProperty("status")]
        public string Status { get; set; }

        [JsonProperty("activeFrom")]
        public DateTime ActiveFrom { get; set; }

        [JsonProperty("activeTo")]
        public DateTime? ActiveTo { get; set; }
    }

    public class DocumentWorkflowParam
    {
        [JsonProperty("id")]
        public int Id { get; set; }

        [JsonProperty("parameter")]
        public string Parameter { get; set; }

        [JsonProperty("value")]
        public int Value { get; set; }

        [JsonProperty("activeFrom")]
        public DateTime ActiveFrom { get; set; }

        [JsonProperty("activeTo")]
        public DateTime? ActiveTo { get; set; }
    }

    public class DocumentTypeById
    {
        [JsonProperty("id")]
        public int Id { get; set; }

        [JsonProperty("name")]
        public string Name { get; set; }

        [JsonProperty("description")]
        public string Description { get; set; }

        [JsonProperty("activeFrom")]
        public DateTime ActiveFrom { get; set; }

        [JsonProperty("activeTo")]
        public object ActiveTo { get; set; }

        [JsonProperty("documentTypeVersions")]
        public List<DocumentTypeVersion2> DocumentTypeVersions { get; set; }

        [JsonProperty("documentWorkflowParams")]
        public List<DocumentWorkflowParam> DocumentWorkflowParams { get; set; }
    }


}
